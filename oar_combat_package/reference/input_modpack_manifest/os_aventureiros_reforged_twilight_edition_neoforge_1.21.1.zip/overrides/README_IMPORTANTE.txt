# Os Aventureiros Reforged — Twilight Edition

Modpack importável no CurseForge.

## Base

- Minecraft: 1.21.1
- Loader: NeoForge 21.1.209
- Java: 21
- Shader recomendado: Sildur's Vibrant Shaders Medium
- Foco: Twilight Forest oficial + Aether + aventura + performance

## Como importar

CurseForge > Minecraft > My Modpacks > Import > escolha este ZIP.

Se a importação reclamar do NeoForge 21.1.209, crie um perfil manual:
Minecraft 1.21.1 + NeoForge, e use este ZIP como referência/lista de mods.

## Mods principais incluídos

Dimensões e aventura:
- The Twilight Forest
- The Aether
- Terralith
- Dungeons and Taverns
- New Classic Battle Towers
- Lootr
- Waystones
- Nature's Compass
- Explorer's Compass
- Traveler's Backpack

Interface:
- JourneyMap
- EMI
- Jade

Performance/shaders:
- Sodium
- Iris Shaders
- ModernFix
- FerriteCore
- Entity Culling
- MoreCulling

Bibliotecas incluídas:
- Balm
- Cumulus
- Accessories
- oωo / owo-lib

## Sildur's Medium

Este ZIP não inclui o arquivo do shader diretamente.
Baixe o Sildur's Vibrant Shaders Medium e coloque o .zip em:

shaderpacks/

Depois abra o jogo:
Options > Video Settings > Shader Packs > Sildur's Vibrant Shaders Medium

## Capa da OptiFine

O caminho NeoForge é mais confiável para Twilight, mas pior para Capes.
O mod Capes que exibe capas de OptiFine é mais simples na rota Fabric/Modrinth.
Nesta Twilight Edition, a recomendação é testar manualmente depois:

1. Abra o perfil no CurseForge.
2. Procure por um mod de capes compatível com NeoForge 1.21.1.
3. Se não achar no CurseForge, use Modrinth/Prism para adicionar Capes manualmente.
4. Não coloque mods Fabric nesse perfil NeoForge.

## Se crashar no primeiro boot

Remova/teste nesta ordem:

1. MoreCulling
2. Entity Culling
3. New Classic Battle Towers
4. Dungeons and Taverns
5. Traveler's Backpack

Twilight Forest, Aether, Balm, Cumulus, Accessories e owo-lib são parte do núcleo e devem ser mantidos para testar a base.

## Servidor

Para servidor dedicado:
- coloque mods de conteúdo e bibliotecas no servidor
- não coloque mods só de cliente/shader

Servidor geralmente precisa:
- Twilight Forest
- Aether
- Cumulus
- Accessories
- owo-lib
- Terralith
- Dungeons and Taverns
- New Classic Battle Towers
- Waystones
- Balm
- Nature's Compass
- Explorer's Compass
- Lootr
- Traveler's Backpack

Só cliente:
- Sodium
- Iris
- Sildur's shader
- JourneyMap pode ser client-only, mas funciona melhor com servidor quando instalado nos dois
- Entity Culling
- MoreCulling
